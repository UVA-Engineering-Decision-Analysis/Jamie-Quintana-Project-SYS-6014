
clear all;
close all;
rng(345); %for reproducability
days = 5; %days to forecast  - set to 30 for baseline - set to 5 for predictor window 
Fdays = 86; %sliding window - days to skip after 12/31/2019, which counts as day 1 - set to 0 to baseline model - no skip days
%Setting days = 33  and Fdays = 0 to predict 2/1/2020 (up or down) with forecast window of 12/31/2019 to 1/31/2020 
%Setting days = 30 and Fdays (skip days) = 3 predicts 2/1/2020 also
%Setting days = 5 and Fdays (skip days) = 86 predicts the last possible day to predict 3/31/2020 
input = csvread('2020_3_31_OPEN_Key.csv');
data = input;
data = data';
input2 = csvread('2020_3_31_CLOSE_Key.csv');
data2 = input2;
data2 = data2';

num = length(input);
fprintf('Last possible day to predict')
DateString = datestr(737790+(num-1845))

Mkey = data2 - data;
Mkey( Mkey >= 0 ) = 1;
Mkey( Mkey < 0 ) = 0;
Mkey = Mkey';
KEY = Mkey(1845+Fdays:1844+Fdays+days);


numTimeStepsTrain = 1844;%1845 = 12/31/2019
WIN = (numTimeStepsTrain+1+days);
dataTrain = data(1:numTimeStepsTrain+1); %train model up to 12/31/2019 
dataTest = data(numTimeStepsTrain+1+Fdays:WIN+Fdays);
mu = mean(dataTrain);
sig = std(dataTrain);
dataTrainStandardized = (dataTrain - mu) / sig;
XTrain = dataTrainStandardized(1:end-1);
YTrain = dataTrainStandardized(2:end);
numFeatures = 1;
numResponses = 1;
numHiddenUnits = 17; %17 = %94.33 

layers = [ ...
    sequenceInputLayer(numFeatures)
    lstmLayer(numHiddenUnits)
    fullyConnectedLayer(numResponses)
    regressionLayer];
    options = trainingOptions('sgdm',... %'sgdm' 'adam'
    'MiniBatchSize',1,...
    'MaxEpochs',175, ...
   'GradientThreshold',1, ...
    'InitialLearnRate',0.08, ...
    'LearnRateSchedule','piecewise', ...
    'LearnRateDropPeriod',125, ...
    'LearnRateDropFactor',0.3, ...
    'Verbose',0, ...
   'Plots','no');
net = trainNetwork(XTrain,YTrain,layers,options);
dataTestStandardized = (dataTest - mu) / sig;
XTest = dataTestStandardized(1:end-1);
net = predictAndUpdateState(net,XTrain);
[net,YPred] = predictAndUpdateState(net,YTrain(end));

numTimeStepsTest = numel(XTest);
for i = 2:numTimeStepsTest
    [net,YPred(:,i)] = predictAndUpdateState(net,YPred(:,i-1),'ExecutionEnvironment','cpu');
end
YPred = sig*YPred + mu;
YTest = dataTest(2:end);
rmse = sqrt(mean((YPred-YTest).^2));

net = resetState(net);
net = predictAndUpdateState(net,XTrain);
YPred = [];
numTimeStepsTest = numel(XTest);
for i = 1:numTimeStepsTest
    [net,YPred(:,i)] = predictAndUpdateState(net,XTest(:,i),'ExecutionEnvironment','cpu');
end
YPred = sig*YPred + mu;
rmse = sqrt(mean((YPred-YTest).^2));


figure
subplot(2,1,1)
plot(YTest)
hold on
plot(YPred,'.-')
hold off
legend(["Observed" "Predicted"])
legend({'Observed','Predicted'},'Location','southeast','NumColumns',2)
ylabel("Price")
title("Forecast")
subplot(2,1,2)
stem(YPred - YTest)
xlabel("Days")
ylabel("Error")
title("RMSE = " + rmse)

DIF = YTest-YPred;
DIF( DIF >= 0 ) = 1;
DIF( DIF < 0 ) = 0;
DIF = DIF';
Percent_of_similar_bits = sum(KEY==DIF)/days;
fprintf('Percentage Correct  : %f%%\n', 100*Percent_of_similar_bits)
tkey = (KEY==DIF);
Fkey = tkey+KEY;
UP_Prob = sum(Fkey==2)/sum(KEY==1)


fprintf('Current day prediction - Up (1) or Down(0)?')
DateString = datestr(737790+days+Fdays)

CDP1 = YPred(end)-mean (YTest);% 5 day windows best
CDP1( CDP1 >= 0 ) = 1;
CDP1( CDP1 < 0 ) = 0;
CDP2 = (YTest(end)-(mean (YPred)*1.05))*-1;
CDP2( CDP2 >= 0 ) = 1;
CDP2( CDP2 < 0 ) = 0;
P_Key = CDP1+CDP2;
if P_Key ==2
    P_Key =1;
else
    P_Key =0;
end


